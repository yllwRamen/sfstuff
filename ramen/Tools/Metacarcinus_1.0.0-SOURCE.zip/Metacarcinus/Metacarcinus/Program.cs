﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Metacarcinus
{
    class Program
    {
        //Metacarcinus magister
        //Variables
        static List<string> LogLines = new List<string>();
        static int threadTime = 3 * 1000;

        static void Main(string[] args)
        {
            LogLines.Add(DateTime.Now.ToString("hh:mm:ss || ") + "Starting Menu...");
            Menu();
        }

        static void pLog(string Text)
        {
            Console.WriteLine(Text);
            LogLines.Add(DateTime.Now.ToString("hh:mm:ss || ") + Text);
        }

        static void pNoLog(string Text)
        {
            Console.WriteLine(Text);
        }

        static void Menu()
        {
            pLog("Menu Started!");
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            pNoLog("+=================================+");
            pNoLog("| -~# Welcome to Metacarcinus #=~ |");
            pNoLog("+=================================+\n");

            Console.ForegroundColor = ConsoleColor.Magenta;
            pNoLog("\tx--------------------x");
            pNoLog("\t| _-= Encryption =-_ |");
            pNoLog("\tx--------------------x");
            pNoLog("\t\t[0] | Encrypt a Tool");
            pNoLog("\t\t[1] | Encrypt a Script\n");

            Console.ForegroundColor = ConsoleColor.Yellow;
            pNoLog("\tx--------------------x");
            pNoLog("\t| _-= Decryption =-_ |");
            pNoLog("\tx--------------------x");
            pNoLog("\t\t[2] | Decrypt a Tool");
            pNoLog("\t\t[3] | Decrypt a Script\n");

            Console.ForegroundColor = ConsoleColor.Gray;
            pNoLog("\tx---------------x");
            pNoLog("\t| _-= Other =-_ |");
            pNoLog("\tx---------------x");
            pNoLog("\t\t[7] | Dump Logs");
            pNoLog("\t\t[8] | About");
            pNoLog("\t\t[9] | Exit\n");

            Console.ForegroundColor = ConsoleColor.Blue;
            pLog("+================================+");
            pLog("| -~# Select an Option:      #~- |");
            pLog("+================================+");
            Console.SetCursorPosition(Console.CursorLeft + 24, Console.CursorTop - 2);
            try
            {
                int opt = int.Parse(Console.ReadLine());
                LogLines.Add(DateTime.Now.ToString("hh:mm:ss || ") + $"opt = {opt}");
                menuSelector(opt);
            }
            catch
            {
                LogLines.Add(DateTime.Now.ToString("hh:mm:ss || ") + "opt is INVALID!");
                Menu();
            }
        }

        static void menuSelector(int opt)
        {
            Console.Clear();

            switch (opt)
            {
                case 0:
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Encrypt_Tool();
                    return;
                case 1:
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Encrypt_Script();
                    return;
                case 2:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Decrypt_Tool();
                    return;
                case 3:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Decrypt_Script();
                    return;
                case 7:
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Dump_Logs();
                    return;
                case 8:
                    Console.ForegroundColor = ConsoleColor.Gray;
                    About();
                    return;
                case 9:
                    Environment.Exit(0);
                    return;
            }
        }

        static void Encrypt_Tool()
        {
            pNoLog("+=========================================+");
            pNoLog("| -~# Drag And Drop A Tool To Compile #~- |");
            pNoLog("+=========================================+\n");

            pLog("+=======================================================+");
            pLog("| -~# File:                                         #~- |");
            pLog("+=======================================================+");
            Console.SetCursorPosition(Console.CursorLeft + 12, Console.CursorTop - 2);
            string encTool_File = Console.ReadLine();
            LogLines.Add(DateTime.Now.ToString("hh:mm:ss || ") + $@"encTool_File = {encTool_File}");

            Thread.Sleep(threadTime);
            Menu();
        }

        static void Encrypt_Script()
        {

        }

        static void Decrypt_Tool()
        {

        }

        static void Decrypt_Script()
        {

        }

        static void Dump_Logs()
        {
            pLog("Writing log...");

            if (!Directory.Exists(Directory.GetCurrentDirectory() + @"\logs"))
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + @"\logs");
            }

            using (StreamWriter DL = File.CreateText(Directory.GetCurrentDirectory() + $@"\logs\{DateTime.Now.ToString("hh_mm_ss")}.log"))
            {
                for (int count = 0; count < LogLines.Count; count++)
                    DL.WriteLine(LogLines[count]);
            }

            pLog("Log written!");
            Thread.Sleep(threadTime);
            Menu();
        }

        static void About()
        {
            pNoLog("+============================+");
            pNoLog("| -~# About Metacarcinus #~- |");
            pNoLog("+============================+\n");

            pNoLog("Version: 1.0.0");
            pNoLog("Published by the SystemFags Team");
            pNoLog("Developers: ");
            pNoLog("\tCCole_BT");
            pNoLog("\tclem_Chase");
            pNoLog("\tf.Murd0ff");
            pNoLog("\tFruitL00p");
            pNoLog("\tnullbyte");
            pNoLog("\tpwn.rycan");
            pNoLog("\trow.katie");
            pNoLog("\tTetraxii\n");

            pNoLog("+=============================================+");
            pNoLog("| -~# Press ANY Key To Return To The Menu #~- |");
            pNoLog("+=============================================+");
            Console.SetCursorPosition(Console.CursorLeft + 47, Console.CursorTop - 2);
            Console.ReadLine();
            Menu();
        }
    }
}
